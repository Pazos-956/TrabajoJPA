package gei.id.tutelado;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ P01_PersonaFisica.class, P03_Declaracion.class, P02_PersonaJuridica.class, P04_Consultas.class } )
public class AllTests {

}
