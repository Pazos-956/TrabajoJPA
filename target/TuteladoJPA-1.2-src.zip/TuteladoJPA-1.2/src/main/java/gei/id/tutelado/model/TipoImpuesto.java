package gei.id.tutelado.model;

public enum TipoImpuesto {
    IVA, IRPF, IS, IBI, IVTM
}
